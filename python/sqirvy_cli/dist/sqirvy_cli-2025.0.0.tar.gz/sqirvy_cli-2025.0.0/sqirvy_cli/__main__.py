"""
Main entry point for the Sqirvy CLI.
"""

from . import main  # pylint: disable = no-name-in-module

if __name__ == "__main__":
    main.main()
